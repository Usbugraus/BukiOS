﻿
Bu dosyayı çalıştırınca `rich` Markdown metnini terminale render eder; kod bloklarına syntax highlighting uygulanır. :contentReference[oaicite:1]{index=1}

---

# 2) `rich` ile desteklenen ana Markdown yapıları (özet)

- **Başlıklar**: `#`, `##`, ..., `######`. (Heading elementleri desteklenir.) :contentReference[oaicite:2]{index=2}  
- **Paragraf**: normal satırlar/bloklar.  
- **Vurgu/İtalik**: `*italic*` veya `_italic_`.  
- **Kalın**: `**bold**` veya `__bold__`.  
- **Üstü çizili (strikethrough)**: `~~silinmiş~~`.  
- **Inline kod**: `` `kod` ``.  
- **Kod blokları**: üç backtick ile (```` ```lang ... ``` ````). **Sözdizmesi renklendirmesi** (Pygments) uygulanır; tema parametresi verilebilir. :contentReference[oaicite:3]{index=3}  
- **Alıntılar (blockquote)**: `>` ile.  
- **Yatay çizgi (horizontal rule)**: `---` veya `***`.  
- **Listeler**:  
  - Sırasız: `-`, `*`, `+`  
  - Sıralı: `1.`, `2.`  
  - İçiçe (nested) listeler desteklenir.  
- **Linkler**: `[metin](https://url)` — bağlantılar desteklenir; `Markdown(..., hyperlinks=True)` ile aktif hale getirilebilir. :contentReference[oaicite:4]{index=4}  
- **Tablolar**: Pipe (`|`) tablolama (özellikle GitHub-styled tablolar) desteklenir — `rich` kendi tablo renderer’ına çevirir. :contentReference[oaicite:5]{index=5}  
- **Resimler (`![alt](url)`)**: `rich` dokümantasyonunda `ImageItem` sınıfı var; Markdown’daki resim sözdizimi **terminalde bir yer tutucu** veya bağlantı/alt metin olarak gösterilir (gerçek resim gösterimi terminale göre sınırlıdır). Yani resim etiketleri görsel olarak her terminalde gerçek resmi göstermez (placeholder / alt-text davranışı olabilir). :contentReference[oaicite:6]{index=6}

---

# 3) `rich`’in **özel davranışları / sınırlamalar** (bilmeniz gerekenler)

1. **Kod blokları doğrudan sözdizim renklendirilir** — `Markdown(..., code_theme="monokai")` gibi `code_theme` ile tema seçebilirsiniz. :contentReference[oaicite:7]{index=7}  
2. **Resimler** çoğu terminalde gerçek görüntü yerine *placeholder* veya alt metin gösterilir; tam görsel desteği terminale/ortama bağlıdır. :contentReference[oaicite:8]{index=8}  
3. **Bazı Markdown uzantıları (flavors)** — örn. GFM task-list (`- [ ]`, `- [x]`) veya footnotes gibi uzantıların **interaktif** veya tam destekli davranışı `rich`’te garanti değildir. Markdown-it tabanlı parser kullanılıyor; `rich` kendi elementlerini oluşturuyor ama bazı eklentiler varsayılan değil. Bu tip uzantılara ihtiyaç varsa önce metni ön işlemden geçirip `rich` için uygun render şeklinde dönüştürmek gerekir. (Örnek: task listleri emoji ile `- [ ]` → `- ☐` gibi dönüştürebilirsiniz.)  
4. **Inline HTML** genellikle terminal renderer’ında işlenmez; HTML etiketleri düz metin veya yok sayılabilir.  
5. `Markdown` sınıfında `hyperlinks=True/False`, `inline_code_lexer`, `inline_code_theme` gibi parametreler bulunur — bunları kullanarak davranışı ince ayarlayabilirsiniz. :contentReference[oaicite:9]{index=9}

---

# 4) İleri ipuçları / öneriler
- Eğer özel bir Markdown uzantısı (ör. task-lists, footnotes, mermaid diyagramları) kullanıyorsanız, iki yol öneririm:
  1. Markdown'ı **ön işlem** ile `rich`'in desteklediği forma dönüştürün (ör. `- [ ]` → `- ☐`).  
  2. Ya da task-list / footnote gibi özelliği önce parse edip `rich` bileşenleriyle (ör. `Table`, `Panel`, özel renderable) manuel render edin.  
- Kod bloklarında farklı tema isterseniz `Markdown(MARKDOWN, code_theme="fruity")` gibi `code_theme` verin; desteklenen temalar Pygments stilleridir. :contentReference[oaicite:10]{index=10}
- Uzun tablolar veya karmaşık veri için `rich.table.Table` sınıfını kullanmak genelde daha iyi görünürlük verir (Markdown tablosu küçük dosyalar için güzel; programatik tablolar için `Table` daha güçlü). :contentReference[oaicite:11]{index=11}

---

# 5) Kaynaklar (özlü)
- Rich Markdown — Quick start & example. :contentReference[oaicite:12]{index=12}  
- `rich.markdown` referansı (element sınıfları: Heading, CodeBlock, Link, TableElement, ImageItem, vs.). :contentReference[oaicite:13]{index=13}  
- `rich` Table dokümantasyonu (programatik tablolar için). :contentReference[oaicite:14]{index=14}

---

İstersen:  
- Sana tek bir örnek Markdown dosyası daha ayrıntılı hazırlayayım (task-list ve footnote için nasıl ön-işlem yapabileceğini gösteren örnek kodla).  
- Veya `rich` ile Markdown içinde **şekil** (diagram) veya ASCII-art eklemek istersen, onu `Panel`/`Columns`/`Syntax` bileşenleriyle nasıl koruyup birlikte gösterileceğini doğrudan kodla hazırlayayım.

Hangiini istersin? (İstersen doğrudan örnekleri genişletip hazır bir `.py` demosu bırakırım — hemen çalışacak şekilde.)
::contentReference[oaicite:15]{index=15}
